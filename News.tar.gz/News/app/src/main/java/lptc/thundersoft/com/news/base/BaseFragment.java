package lptc.thundersoft.com.news.base;

/**
 * Created by zxf on 16-7-29.
 */
public class BaseFragment {
}
