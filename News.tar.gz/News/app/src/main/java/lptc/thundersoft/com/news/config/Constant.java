package lptc.thundersoft.com.news.config;

/**
 * Created by zxf on 16-7-29.
 */

/**
 * 常量存储
 */
public class Constant {

}
